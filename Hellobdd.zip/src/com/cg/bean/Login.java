package com.cg.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Login {

	@FindBy(id = "userName")
	private WebElement userName;

	@FindBy(id = "password")
	private WebElement password;

	@FindBy(id = "login")
	private WebElement login;
	
	@FindBy(id="role")
	private WebElement role;
	
	@FindBy(id="user")
	private List<WebElement> user;
	
	@FindBy(id="check")
	private WebElement check;

	public String getRole() {
		return role.getAttribute("value");
	}

	public void setRole(String role) {
		this.role.sendKeys(role);;
	}

	public String getUserName() {
		return userName.getAttribute("value");
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public String getLogin() {
		return login.getAttribute("value");
	}

	public void setLogin(String login) {
		this.login.sendKeys(login);
	}	
		public void clickLogin() {
			login.click();
		}
		
		public void clickRole(int index) {
			Select select = new Select(role);
			select.selectByIndex(index);
		}
		
		public void selectUser(int idx) {
			this.user.get(idx).click();;
		}
		public void clickCheck() {
			check.click();
		}

	}


