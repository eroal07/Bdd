package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Login;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefination2 {

	private WebDriver driver;
	private Login login;

	@Before
	public void init() {
		// Instantiate driver
		System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		String url = "file:///C:/Users/edabre/workspaceM2/HelloBDD/html/login.html";
		driver.get(url);
		login = new Login();
		PageFactory.initElements(driver, login);
	}

	@When("^User enters valid user$")
	public void user_enters_valid_user() throws Throwable {
		login.selectUser(1);
	}

	@Then("^Validate user$")
	public void validate_user() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters valid username$")
	public void user_enters_valid_username() throws Throwable {
		login.selectUser(0);
		login.setUserName("abc");
	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters valid password$")
	public void user_enters_valid_password() throws Throwable {
		login.selectUser(0);
		login.setUserName("abcd");
		login.setPassword("123");

	}

	@Then("^Validate password$")
	public void validate_password() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enter valid role$")
	public void user_enter_valid_role() throws Throwable {
		login.selectUser(0);
		login.setUserName("abcd");
		login.setPassword("1253");
		login.clickRole(0);
		Thread.sleep(5000);

	}

	@Then("^Validate role$")
	public void validate_role() throws Throwable {

		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}
	
	@When("^User enters invalid check$")
	public void user_enters_invalid_check() throws Throwable {
		login.selectUser(0);
		login.setUserName("abcd");
		login.setPassword("1234");
		login.clickRole(1);

	}

	@Then("^Validate check$")
	public void validate_check() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		
	}

	@When("^User submit form$")
	public void user_submit_form() throws Throwable {
		login.selectUser(0);
		login.setUserName("abcd");
		login.setPassword("1234");
		login.clickRole(1);
		login.clickCheck();

	}
	

	@Then("^Show Successfull alert$")
	public void show_Successfull_alert() throws Throwable {
		// alert
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

}
