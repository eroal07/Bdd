package com.cg.step;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HelloCucumberStepDefination {

	@Given("^Attended Training$")
	public void attended_Training() throws Throwable {
	    System.out.println("1-Attend Training");
	}

	@When("^Clear L(\\d+)$")
	public void clear_L(int arg1) throws Throwable {
		System.out.println("2-Clear L1");
	}

	@Then("^Become Employee$")
	public void become_Employee() throws Throwable {
		System.out.println("3-I m Good Employee of CG");
	}

	@Before(order=0)
	public void init() {
		System.out.println("Secanrio test begin");
	}
	
	@After(order=0)
	public void destroy() {
		System.out.println("Scenerio test ends");
	}

	@Given("^Hello given step$")
	public void Hello_Given_Step() throws Throwable {
		System.out.println("Saying Hello to given step");
	}

	@When("^Hello when step$")
	public void Hello_When_Step() throws Throwable {
		System.out.println("Saying Hello to when step");
	}

	@Then("^Hello then step$")
	public void Hello_Then_Step() throws Throwable {
		System.out.println("Saying Hello to when step");
	}

	@Given("^Bye given step$")
	public void bye_given_step() throws Throwable {
		System.out.println("Saying Bye to given step");
	}

	@When("^Bye when step$")
	public void bye_when_step() throws Throwable {
		System.out.println("Saying Bye to when step");
	}

	@Then("^Bye then step$")
	public void bye_then_step() throws Throwable {
		System.out.println("Saying Bye to when step");
	}

}
