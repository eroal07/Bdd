/*package com.cg.step;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefination {

	private WebDriver driver;

	@Before
	public void init() {
		// Instantiate driver
		System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		String url = "file:///C:/Users/edabre/workspaceM2/HelloBDD/html/login.html";
		driver.get(url);
	}

	@When("^User enters valid username$")
	public void user_enters_valid_username() throws Throwable {
		WebElement uname = driver.findElement(By.id("userName"));
		uname.sendKeys("abc");
	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
		WebElement login = driver.findElement(By.id("login"));
		login.click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters valid password$")
	public void user_enters_valid_password() throws Throwable {
		
		WebElement uname = driver.findElement(By.id("userName"));
		uname.sendKeys("abcd");
		WebElement pass = driver.findElement(By.id("password"));
		pass.sendKeys("123");

	}

	@Then("^Validate password$")
	public void validate_password() throws Throwable {
		WebElement login = driver.findElement(By.id("login"));
		login.click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User submit form$")
	public void user_submit_form() throws Throwable {
		WebElement uname = driver.findElement(By.id("userName"));
		uname.sendKeys("abcd");
		WebElement pass = driver.findElement(By.id("password"));
		pass.sendKeys("1234");
	}

	@Then("^Show Successfull alert$")
	public void show_Successfull_alert() throws Throwable {
		// alert
		WebElement login = driver.findElement(By.id("login"));
		login.click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		
	}

}
*/