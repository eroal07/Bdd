package hotelbookingPageFactory;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class hotelbookingPageFactory 
{
	WebDriver driver;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement formfirstname;
	
	@FindBy(how=How.ID,using="txtLastName")
	@CacheLookup
	WebElement formlastname;
	
	@FindBy(how=How.NAME,using="Email")
	@CacheLookup
	WebElement formemail;
	
	@FindBy(how=How.ID,using="txtPhone")
	@CacheLookup
	WebElement formfone;
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
	@CacheLookup
	WebElement formaddress;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement formcity;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement formstate;
	
	@FindBy(name="persons")
	@CacheLookup
	WebElement formnoofpersons;
	
	@FindBy(css="#txtCardholderName")
	@CacheLookup
	WebElement formcardholdername;
	
	@FindBy(xpath="//*[@id='txtDebit']")
	@CacheLookup
	WebElement formdebitCardno;
	
	@FindBy(how=How.ID,using="txtCvv")
	@CacheLookup
	WebElement formCVV;
	
	@FindBy(how=How.XPATH,using="/html/body/h1")
	@CacheLookup
	WebElement successmsg;
	
	public String getsuccessmsg()
	{
		return successmsg.getText();
	}
	
	public WebElement getFormdebitCardno() {
		return formdebitCardno;
	}

	public void setFormdebitCardno(String debitCardno)
	{
		this.formdebitCardno.sendKeys(debitCardno);
	}

	public WebElement getFormCVV() {
		return formCVV;
	}

	public void setFormCVV(String CVV) {
		this.formCVV.sendKeys(CVV);
	}

	public WebElement getFormexpmonth() {
		return formexpmonth;
	}

	public void setFormexpmonth(String expmonth) {
		this.formexpmonth.sendKeys(expmonth);
	}

	public WebElement getFormexpyear() {
		return formexpyear;
	}

	public void setFormexpyear(String expyear) {
		this.formexpyear.sendKeys(expyear);
	}



	@FindBy(how=How.XPATH,using="//*[@id=\"txtMonth\"]")
	@CacheLookup
	WebElement formexpmonth;
	
	@FindBy(how=How.CSS,using="#txtYear")
	@CacheLookup
	WebElement formexpyear;
	
	public WebElement getFormcardholdername() {
		return formcardholdername;
	}

	public void setFormcardholdername(String cardholdername) {
		this.formcardholdername.sendKeys(cardholdername);
	}
	


	@FindBy(className="btn")
	@CacheLookup
	WebElement confirmbtn;
	
	public WebElement getConfirmbtn() {
		return confirmbtn;
	}

	public void setConfirmbtn() {
		this.confirmbtn.click();
	}

	public WebElement getFormfirstname() {
		return formfirstname;
	}

	public void setFormfirstname(String firstname) 
	{
		formfirstname.sendKeys(firstname);	
		
	}	
	
	public WebElement getFormlastname() {
		return formlastname;
	}

	public void setFormlastname(String lastname) {
		formlastname.sendKeys(lastname);
	}

	public WebElement getFormemail() {
		return formemail;
	}

	public void setFormemail(String email) {
		this.formemail.sendKeys(email);
	}

	public WebElement getFormfone() {
		return formfone;
	}

	public void setFormfone(String fone) {
		//String fone= fone.toString();
		this.formfone.sendKeys(fone);
	}

	public WebElement getFormaddress() {
		return formaddress;
	}

	public void setFormaddress(String address) {
		this.formaddress.sendKeys(address);
	}

	public WebElement getFormcity() {
		return formcity;
	}

	public void setFormcity(String city) {
		Select cityobj= new Select(formcity);
		cityobj.selectByVisibleText(city);
	}

	public WebElement getFormstate() {
		return formstate;
	}

	public void setFormstate(String state) {
		Select stateobj= new Select(formstate);
		stateobj.selectByValue(state);
	}

	public WebElement getFormnoofpersons() {
		return formnoofpersons;
	}

	public void setFormnoofpersons(String noofpersons) {
		this.formnoofpersons.sendKeys(noofpersons);
	}


	public hotelbookingPageFactory(WebDriver driver)
	{
		// TODO Auto-generated constructor stub
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	
}
