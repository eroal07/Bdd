package org.main.model;

public class Address
{
	private int houseno;
	private String buildingname;
	public int getHouseno()
	{
		return houseno;
	}
	public void setHouseno(int houseno)
	{
		this.houseno = houseno;
	}
	public String getBuildingname() 
	{
		return buildingname;
	}
	public void setBuildingname(String buildingname) 
	{
		this.buildingname = buildingname;
	}
	public Address(int houseno, String buildingname) {
		super();
		this.houseno = houseno;
		this.buildingname = buildingname;
	}
	@Override
	public String toString() {
		return "Address [houseno=" + houseno + ", buildingname=" + buildingname + "]";
	}
}
