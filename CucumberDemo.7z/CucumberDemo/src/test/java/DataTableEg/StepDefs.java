package DataTableEg;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs 
{
	WebDriver driver;
	
	@Given("^User launches the browser and opens the application$")
	public void user_launches_the_browser_and_opens_the_application() throws Throwable
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/athomson/chromedriver.exe");
		 driver= new ChromeDriver();
		 driver.get("C:\\Users\\athomson\\Documents\\BDD\\BDD\\hotelBooking\\login.html");

	}

	@When("^User enters the valid username and valid password$")
	public void user_enters_the_valid_username_and_valid_password(DataTable arg1) throws Throwable
	{
		//System.out.println(arg1);
		List<List<String>> dtobj= arg1.raw();
		
		
		driver.findElement(By.name("userName")).sendKeys(dtobj.get(0).get(0));
		driver.findElement(By.name("userPwd")).sendKeys(dtobj.get(0).get(1));
	


	}

	@Then("^Application takes to the 'Hotel booking' page$")
	public void application_takes_to_the_Hotel_booking_page() throws Throwable {
		driver.findElement(By.className("btn")).click();
		driver.close();
	}

}
