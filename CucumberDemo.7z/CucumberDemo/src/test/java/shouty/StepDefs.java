package shouty;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs {

@Given("^There are three people$")
public void there_are_two_people() throws Throwable {
    System.out.println("This is the given part");
}

@When("^Alphy and Ancy are (\\d+) meters away$")
public void alphy_and_Ancy_are_meters_away(int arg1) throws Throwable {
    System.out.println("This is the when part");
}

@When("^they are talking with each other$")
public void they_are_talking_with_each_other() throws Throwable {
    System.out.println("This is the 2nd when part");
}

@Then("^There will be an echo$")
public void there_will_be_an_echo() throws Throwable {
    System.out.println("This is the Then part");
}



}
