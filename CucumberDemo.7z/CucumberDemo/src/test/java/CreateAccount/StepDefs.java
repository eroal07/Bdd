package CreateAccount;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Random;

import org.main.model.Address;
import org.main.model.Customer;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs {
	
	private Customer cust;
	private int acctbal;
	private int acctno;
	
	@Given("^Account details and Customer details$")
	public void account_details_and_Customer_details() throws Throwable
	{	
		Address address= new Address(152, "Vijetha");
		 cust= new Customer("Alphy", "Thomson", address);
		//System.out.println(cust);
		//System.out.println(address);
		acctbal=500;
	}
	
	@When("^Customer details are valid$")
	public void customer_details_are_valid() throws Throwable {
		System.out.println(cust);
	  assertNotNull(cust);
	}

	@When("^Account details are valid$")
	public void account_details_are_valid() throws Throwable {
		assertEquals(500, acctbal);
		assertNotNull(acctbal);
	}

	

	@Then("^Generate Accountno$")
	public void generate_Accountno() throws Throwable {
		Random rand= new Random();
	   acctno=rand.nextInt(10000);
	   assertNotNull(acctno);
	   System.out.println(acctno);
	}

	@Then("^Store in database$")
	public void store_in_database() throws Throwable {
		   System.out.println(acctno);

	}



}
