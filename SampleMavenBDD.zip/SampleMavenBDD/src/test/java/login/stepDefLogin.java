package login;

import java.io.File;

import org.junit.Assert;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;


import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import pageBean.HotelLoginPageFactory;

public class stepDefLogin {

	private static WebDriver driver;
	private HotelLoginPageFactory objhlpg;
	String BaseURL,NodeURL;
	
	
	@Before
	public void beforeLogin()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	@Given("^User is on 'login' Page$")
	public void user_is_on_login_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//driver = new FirefoxDriver();
		//	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//driver = new FirefoxDriver();
		
		System.out.println("driver = "+driver);
			objhlpg = new HotelLoginPageFactory(driver);

			driver.get("d:\\WebDriver\\login.html");
	   // throw new PendingException();
	}

	@When("^user enters invalid UserName$")
	public void user_enters_invalid_UserName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    objhlpg.setPfuname("");
	    objhlpg.setPflogin();
	    
	    
	}

	@Then("^display 'Please Enter UserName'$")
	public void display_Please_Enter_UserName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    String str = objhlpg.getPfuserError().getText();
	    String eStr = "* Please enter userName." ;
	    Assert.assertEquals(eStr, str);
	    
	}

	@When("^user enters invalid password$")
	public void user_enters_invalid_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		objhlpg.setPfuname("Abc");
		 //objhlpg.setPflogin();
	    objhlpg.setPfpwd("");
	    objhlpg.setPflogin();
	}

	@Then("^display 'Please Enter Password'$")
	public void display_Please_Enter_Password() throws Throwable {
	    String pwdStr = objhlpg.getPfpwdError().getText();
	    String epwdStr = "* Please enter password.";
	   
	    Assert.assertEquals(epwdStr,pwdStr);
	    
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    objhlpg.setPfuname("Capgemini");
	    objhlpg.setPfpwd("capg1234");
	}

	@Then("^display 'HotelBooking' Page$")
	public void display_HotelBooking_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    driver.get("d:\\WebDriver\\hotelbooking.html");
	}

}
